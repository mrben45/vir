clear
toilet -f big -F gay VIRTEX
echo " author : mr45card" |lolcat
echo ""
echo "> 085320200481"
echo "> 087708967977"
echo "> 087898306613"
echo "> keluar"
echo ""
echo "  MASUKAN NOMOR YANG MAU DI SPAM"
read -p " no : " pil;

case $pil in
085320200481)
echo ""
sleep 0.5
echo "  LOADING..."
sleep 0.5
sh list.sh
sh virtex.sh
exit
;;

087708967977)
echo ""
sleep 0.5
echo "  LOADING..."
sleep 0.5
sh list2.sh
sh virtex.sh
exit
;;

087898306613)
echo ""
sleep 0.5
echo "  LOADING..."
sleep 0.5
sh list3.sh
sh virtex.sh
exit
;;

keluar)
echo ""
sleep 0.5
echo "  LOADING..."
sleep 0.5
exit
;;
*)
sleep 0.5
echo "  LOADING..."
sleep 0.5
echo ""
echo "   PERINTAH SALAH!"
sleep 3
sh virtex.sh
exit
esac
exit
done
